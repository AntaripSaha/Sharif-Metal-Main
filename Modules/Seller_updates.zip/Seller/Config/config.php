<?php

return [
    'name' => 'Seller'
];
