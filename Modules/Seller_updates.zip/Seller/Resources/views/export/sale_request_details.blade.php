<table>
    <thead>
        <th>GJUDVGCKJDSB</th>
    </thead>

    <tbody>
        <tr>
            <td>cdfksjbvdfkjvn</td>
        </tr>
    </tbody>
</table>