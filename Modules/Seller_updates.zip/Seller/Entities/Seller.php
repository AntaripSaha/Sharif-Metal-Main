<?php

namespace Modules\Seller\Entities;

use Illuminate\Database\Eloquent\Model;

class Seller extends Model
{
    protected $fillable = [];
}
